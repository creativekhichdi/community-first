# WGL Customized Redux Framework Changelog

## 4.1.24
* Change domain name to redux-framework
* ./class.redux-plugin
* ./redux-core/inc/classes/class-redux-page-render
* ./redux-core/inc/classes/class-redux-output: Custom Typography
* ./redux-core/class-redux-core
* ./redux-core/inc/classes/class-redux-wordpress-data
* Remove: Redux_Functions_Ex::generator();


* ./redux-core/inc/fields/typography/redux-typography.js
